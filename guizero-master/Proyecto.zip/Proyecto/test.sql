USE Proyecto;
/*
INSERT INTO Score(int_points,int_idGame_fk) VALUES(0,1);
INSERT INTO User(tex_name, tex_password, int_idScore_fk,int_idRole_fk) VALUES('Alonso','eduka',1,1);
SELECT * FROM Roles;
SELECT *FROM Game;
SELECT * FROM Score;
SELECT * FROM User;
*/

DELIMITER//

    CREATE FUNCTION SaveScore(score int)
    BEGIN
        INSERT INTO Score(int_points) VALUES (score)
    END//

DELIMITER;